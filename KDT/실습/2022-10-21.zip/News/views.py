from django.shortcuts import render
from .crawling import naver_news_search
from django.core.paginator import Paginator
# Create your views here.

def index(request):
    news = naver_news_search('자폐', 1)
    page = int(request.GET.get('p', 1))
    pagenator = Paginator(news, 10)
    boards = pagenator.get_page(page)
    context = {
        'news':news,
    }
    return render(request, "News/index.html", context)