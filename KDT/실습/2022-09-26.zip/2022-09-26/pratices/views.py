from django.shortcuts import render
import random

# Create your views here.

# 1번
def numbers(request, n1):
    num = n1

    if n1 == 0:
        check = 0
    else:
        if n1 % 2:
            check = "홀수"
        else:
            check = "짝수"
    context = {
        "num": num,
        "check": check,
    }
    return render(request, "is-odd-even.html", context)


# 2번
def cal(request, number1, number2):
    context = {
        "number1": number1,
        "number2": number2,
        "a": number1 + number2,
        "b": number1 - number2,
        "c": number1 * number2,
        "d": number1 // number2,
    }
    return render(request, "calculate.html", context)


# 3번
def name(request):
    return render(request, "name.html")


def junsang(request):
    past_lifes = ["음악가", "과학자", "수학자", "하인", "왕", "여왕", "무도가", "말", "돼지", "용", "정조"]
    nname = request.GET.get("name")
    past_life = "".join(map(str, random.sample(past_lifes, 1)))

    context = {"name": nname, "past": past_life}
    return render(request, "junsang.html", context)


# 4번
def lorm_number(request):
    return render(request, "lorm_number.html")


def lorm_check(request):
    a = int(request.GET.get("num1"))
    b = int(request.GET.get("num2"))

    han = ["바나나", "초코", "사과", "포도", "짜장면", "딸기"]
    texts = [[] for _ in range(a)]
    for i in range(a):
        for _ in range(b):
            texts[i].append("".join(map(str, random.sample(han, 1))))
    context = {
        "text": texts,
        "a": a,
        "b": b,
    }
    return render(request, "lorm_check.html", context)
