from django.shortcuts import render, redirect
from .forms import UsersForm
from django.contrib.auth import get_user_model
from django.contrib.auth.hashers import make_password,check_password
# Create your views here.


def home(request):
    all = get_user_model().objects.all()
    context = {
        'v':all
    }
    return render(request,"accounts/home.html",context)
def signup(request):
    if request.method == "POST":
        form = UsersForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect("accounts:home")
    else:
        form = UsersForm()
    context ={
        'form':form
    }
    return render(request,"accounts/signup.html", context)
def detail(request, pk):
    user = get_user_model().objects.get(pk=pk)
    context = {
        'user': user
    }
    return render(request, 'accounts/detail.html', context)
def login(request):
    response_data = {}

    if request.method == "GET" :
        return render(request, 'accounts/login.html')

    elif request.method == "POST":
        login_username = request.POST.get('username', None)
        login_password = request.POST.get('password', None)


        if not (login_username and login_password):
            response_data['error']="아이디와 비밀번호를 모두 입력해주세요."
        else : 
            myuser = get_user_model().objects.get(username=login_username) 
            #db에서 꺼내는 명령. Post로 받아온 username으로 , db의 username을 꺼내온다.
            if check_password(login_password, myuser.password):
                request.session['user'] = myuser.id
                request.session['username'] = myuser.username
                #세션도 딕셔너리 변수 사용과 똑같이 사용하면 된다.
                #세션 user라는 key에 방금 로그인한 id를 저장한것.
                return redirect('accounts:home')
            else:
                response_data['error'] = "비밀번호를 틀렸습니다."

        return render(request, 'accounts/login.html', response_data)
def logout(request):
    request.session.pop('user')
    request.session.pop('username')
    return redirect('accounts:home')