from django.shortcuts import render,redirect,get_object_or_404
from .models import Article
from .forms import ArticleForm
from django.views.decorators.http import require_POST
from django.contrib.auth.decorators import login_required


def index(request):
    all = Article.objects.all().order_by('id')
    context={
        "v":all
    }
    return render(request, 'articles/index.html', context)

@login_required()
def create(request):
    if request.method == "POST":
        Article_Form = ArticleForm(request.POST)
        if Article_Form.is_valid():
            post = Article_Form.save(commit=False)
            post.user = request.user
            post.save()
            return redirect("articles:index")
    else:
        Article_Form = ArticleForm()
    return render(request, "articles/create.html",{"Article_Form":Article_Form})

@login_required()
def detail(request, pk):
    k = Article.objects.get(pk = pk)
    article = get_object_or_404(Article, pk=pk)
    context = {
        "v": k,
        "v1": article.like_users.all(),
        "v2":article.like_users.count
    }
    return render(request, "articles/detail.html", context)

@login_required()
def delete(request, pk):
    Article.objects.get(pk=pk).delete()
    return redirect("articles:index")

@login_required()
def update(request, pk):
    k = Article.objects.get(pk=pk)
    if request.method == "POST":
        Article_Form = ArticleForm(request.POST, instance=k)
        if Article_Form.is_valid():
            Article_Form.save()
            return redirect("articles:index")
    else:
        Article_Form = ArticleForm(instance=k)
    return render(request, "articles/update.html",{"Article_Form":Article_Form ,"v":k})

@login_required()
def like(request, pk):
    article = get_object_or_404(Article, pk=pk)
    if article.like_users.filter(id=request.user.pk).exists():
        article.like_users.remove(request.user)
    else:
        article.like_users.add(request.user)
    return redirect('articles:detail', pk)