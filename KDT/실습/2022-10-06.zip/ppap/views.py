from django.shortcuts import render,redirect
from .models import Movie
from .forms import MovieForm
# Create your views here.

def index(request):
    k = Movie.objects.all().order_by("-id")
    context = {
        "v":k
    }
    return render(request,"ppap/index.html", context)

def create(request):
    if request.method == "POST":
        ppap_form = MovieForm(request.POST)
        if ppap_form.is_valid():
            ppap_form.save()
            return redirect("/")
    else:
        ppap_form = MovieForm()
    context = {
        'ppap_form':ppap_form
    }
    return render(request, "ppap/create.html", context)

def detail(request, pk):
    k = Movie.objects.get(pk=pk)
    context = {
        "v":k
    }
    return render(request, "ppap/detail.html", context)
def delete(request, pk):
    Movie.objects.get(pk=pk).delete()
    return redirect('/')

def update(request, pk):
    k = Movie.objects.get(pk=pk)
    if request.method == "POST":
        ppap_form = MovieForm(request.POST, instance=k)
        if ppap_form.is_valid():
            ppap_form.save()
            return redirect("/", k.pk)
    else:
        ppap_form = MovieForm(instance=k)
    context = {
        "ppap_form":ppap_form,
        "c":k
        }
    return render(request, "ppap/update.html", context)