from django.shortcuts import render
import random
import requests

# Create your views here.

def lottos(request):
    val_input = input('Input round number : ')

    url = 'https://www.dhlottery.co.kr/common.do?method=getLottoNumber&drwNo={}'
    url = url.format(val_input)
    req_result = requests.get(url)
    json_result = req_result.json()

    val_return_success = json_result.get('returnValue', None)
    val_drw_dt = json_result.get('drwNoDate', None)
    val_no_1 = json_result.get('drwtNo1', None)
    val_no_2 = json_result.get('drwtNo2', None)
    val_no_3 = json_result.get('drwtNo3', None)
    val_no_4 = json_result.get('drwtNo4', None)
    val_no_5 = json_result.get('drwtNo5', None)
    val_no_6 = json_result.get('drwtNo6', None)
    val_bonus_no = json_result.get('bnusNo', None)
    lotto_win = [val_no_1, val_no_2, val_no_3, val_no_4, val_no_5, val_no_6]

    lotto_list = []

    for _ in range(5):
        lotto = random.sample(range(1, 46), 6)
        count = 0
        result = 0

        for num in lotto:
            if num in lotto_win:
                count += 1
        
        if count == 3:
            result = 5
        elif count == 4:
            result = 4
        elif count == 5:
            if lotto_win[-1] not in lotto:
                result = 3
            else:
                result = 2
        elif count == 6:
            result = 1
        lotto_list.append((lotto, result))

        context = {
            "lotto_winner" : lotto_win,
            "bonus" : val_bonus_no,
            "lotto_list": lotto_list,
            "lotto_win":lotto_win,
            "number":val_input,
        }
    return render(request, 'lotto.html', context)

def menu(request):
    menus = [['삼겹살', 'https://cdn.mindgil.com/news/photo/202103/70839_7148_1250.jpg'],
    ['짜장면', 'https://src.hidoc.co.kr/image/lib/2021/8/27/1630049987719_0.jpg'],
    ['돈까스', 'https://en.pimg.jp/054/228/457/1/54228457.jpg'],
    ['냉면', 'https://m.yorivery.com/data/goods/20/05/21//1000000878/1000000878_detail_143.jpg']]
    menu = random.choices(menus)
    context = {
        'menu':menu[0][0],
        'imgs':menu[0][1],
    }
    return render(request, 'menu.html', context)