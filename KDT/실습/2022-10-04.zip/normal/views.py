import re
from django.shortcuts import render,redirect
from .forms import HyunSikForm
from .models import HyunSik
# Create your views here.

def index(request):
    content = HyunSik.objects.order_by('-pk')
    context = {
        'c': content
    }
    return render(request, 'normal/index.html', context)

def create(request):
    if request.method == "POST":
        HyunSik_Form = HyunSikForm(request.POST)
        if HyunSik_Form.is_valid():
            HyunSik_Form.save()
            return redirect('/')
    else:
        HyunSik_Form = HyunSikForm()
    context = {
        'HyunSik_Form': HyunSik_Form
    }
    return render(request, 'normal/create.html', context)
def detail(request, pk):
    k = HyunSik.objects.get(pk=pk)
    context ={
        "c":k
    }
    return render(request,'normal/detail.html', context)
def delete(request, pk):
    HyunSik.objects.get(pk=pk).delete()
    return redirect('/')
def update(request, pk):
    k = HyunSik.objects.get(pk=pk)
    if request.method == "POST":
        HyunSik_Form = HyunSikForm(request.POST, instance=k)
        if HyunSik_Form.is_valid():
            HyunSik_Form.save()
            return redirect('/', k.pk)
    else:
        HyunSik_Form = HyunSikForm(instance=k)
    context = {
        'HyunSik_Form': HyunSik_Form,
        'c':k
    }
    return render(request, 'normal/update.html', context)