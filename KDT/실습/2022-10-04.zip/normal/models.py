from django.db import models

# Create your models here.

class HyunSik(models.Model):
    # name = models.CharField(max_length=20, unique=True) #이름
    title = models.CharField(max_length=20) # 제목
    content = models.TextField() # 내용
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)