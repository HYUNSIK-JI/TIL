from django import forms
from .models import HyunSik

class HyunSikForm(forms.ModelForm):

    class Meta:
        model = HyunSik
        fields = ['title', 'content']